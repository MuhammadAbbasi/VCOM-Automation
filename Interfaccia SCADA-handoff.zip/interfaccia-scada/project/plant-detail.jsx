// Vista dettaglio singolo impianto — Inverter matrix + string monitor
// Stile ispirato a un SCADA esistente ma rielaborato (design originale)

function genInverters(siteId, count) {
  const invs = [];
  const rnd = (s) => { // PRNG deterministico
    let x = 0;
    for (let i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0;
    return () => {
      x = (x * 1664525 + 1013904223) | 0;
      return ((x >>> 0) % 10000) / 10000;
    };
  };
  const r = rnd(siteId);
  // Diversi inverter hanno un numero di MPPT differente (8..14) e per ciascun MPPT
  // un numero di stringhe collegate (3..6)
  for (let i = 1; i <= count; i++) {
    const block = i <= count/3 ? "A" : i <= 2*count/3 ? "B" : "C";
    const roll = r();
    let status = "ok";
    if (roll > 0.93) status = "crit";
    else if (roll > 0.82) status = "warn";
    else if (roll > 0.78) status = "offline";
    const id = `INV-${block}${(((i-1)%(Math.ceil(count/3)))+1).toString().padStart(2,"0")}`;
    const pr = status === "offline" ? 0 : 88 + r()*10;
    const temp = status === "crit" ? 78 + r()*8 : 48 + r()*12;
    const dc = status === "offline" ? 0 : 1050 + r()*120;
    const ac = status === "offline" ? 0 : (pr/100) * (80 + r()*20);
    const mpptCount = 8 + Math.floor(r()*7); // 8..14
    const mppts = Array.from({length: mpptCount}, (_, k) => {
      const stringCount = 3 + Math.floor(r()*4); // 3..6 stringhe per MPPT
      return {
        n: k+1,
        v: 720 + r()*80,
        a: 9 + r()*2.5,
        strings: Array.from({length: stringCount}, (_, j) => {
          const sv = r();
          let state = "ok";
          if (status === "offline") state = "off";
          else if (status === "crit" && sv < 0.25) state = "fault";
          else if (status === "warn" && sv < 0.18) state = "warn";
          else if (sv < 0.03) state = "fault";
          else if (sv < 0.08) state = "warn";
          return { n: j+1, state, a: 9 + r()*2.5 };
        }),
      };
    });
    invs.push({ id, block, status, pr, temp, dc, ac, mppts });
  }
  return invs;
}

function PlantDetail({ site, onBack, t }) {
  const [selInv, setSelInv] = React.useState(null);
  const [matrixMode, setMatrixMode] = React.useState("pr"); // pr | temp | dc | ac
  const inverters = React.useMemo(() => genInverters(site.id, 36), [site.id]);

  const totals = {
    total: inverters.length,
    online: inverters.filter(i => i.status !== "offline").length,
    tripped: inverters.filter(i => i.status === "crit").length,
    comms: inverters.filter(i => i.status === "offline").length,
    avgPr: inverters.reduce((a,i) => a+i.pr, 0)/inverters.length,
    totalAc: inverters.reduce((a,i) => a+i.ac, 0),
  };

  const selected = selInv ? inverters.find(i => i.id === selInv) : null;

  // helpers for matrix cell value
  function cellValue(inv, mode) {
    if (inv.status === "offline") return null;
    if (mode === "pr") return inv.pr;
    if (mode === "temp") return inv.temp;
    if (mode === "dc") return inv.dc;
    if (mode === "ac") return inv.ac;
  }
  function cellFmt(v, mode) {
    if (v == null) return "—";
    if (mode === "pr") return v.toFixed(0) + "%";
    if (mode === "temp") return v.toFixed(0) + "°";
    if (mode === "dc") return v.toFixed(0) + "V";
    if (mode === "ac") return v.toFixed(1) + "kW";
  }

  return (
    <div style={{display:"flex", flexDirection:"column", height:"100%", minHeight: 0, overflow:"auto"}}>
      {/* Plant header with breadcrumb/back */}
      <div style={{padding: "12px 18px 6px", display:"flex", alignItems:"center", gap: 12, borderBottom: "1px solid var(--line)"}}>
        <button className="btn ghost" onClick={onBack} style={{padding: "0 8px"}}>← {t.map}</button>
        <div>
          <div style={{fontSize: 17, fontWeight: 600, letterSpacing:"-0.015em"}}>{site.name} <span style={{color:"var(--fg-muted)", fontFamily:"var(--mono)", fontSize:12, marginLeft: 6}}>{site.id}</span></div>
          <div style={{fontSize: 12, color: "var(--fg-dim)"}}>{site.city} · {site.capacity.toFixed(1)} MWp · {site.panels.toLocaleString()} moduli · in servizio dal {site.commissioned}</div>
        </div>
        <div style={{flex:1}}/>
        <div className="pill mono" style={{background: site.status === "crit" ? "var(--crit-soft)" : site.status === "warn" ? "var(--warn-soft)" : "var(--ok-soft)", color: site.status === "crit" ? "var(--crit)" : site.status === "warn" ? "var(--warn)" : "var(--ok)", border: 0}}>
          <span className="dot" style={{background:"currentColor", boxShadow:"none"}}/>
          {site.status === "ok" ? t.status_ok : site.status === "warn" ? t.status_warn : t.status_crit}
        </div>
      </div>

      {/* Plant KPIs */}
      <div style={{padding: "10px 18px", display:"grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 8}}>
        <PlantKpi label="Inverter totali" value={totals.total} color="var(--fg)"/>
        <PlantKpi label="Online" value={totals.online} color="var(--ok)"/>
        <PlantKpi label="Tripped" value={totals.tripped} color="var(--crit)"/>
        <PlantKpi label="Comms lost" value={totals.comms} color={totals.comms ? "var(--warn)" : "var(--fg-muted)"}/>
        <PlantKpi label="PR medio" value={totals.avgPr.toFixed(1) + "%"} color="var(--accent)"/>
        <PlantKpi label="Potenza AC" value={totals.totalAc.toFixed(0) + " kW"} color="var(--fg)"/>
      </div>

      {/* Matrix + String panel side by side */}
      <div style={{display:"grid", gridTemplateColumns: "1fr 300px", gap: 10, padding: "0 18px 14px", flex: 1, minHeight: 0}}>
        <div className="panel" style={{minHeight: 0}}>
          <div className="panel-head">
            <div>
              <div className="panel-title">Inverter Health Matrix</div>
              <div className="panel-sub">36 inverter · clicca per dettaglio stringhe</div>
            </div>
            <div className="right">
              <div className="seg">
                <button aria-pressed={matrixMode === "pr"} onClick={() => setMatrixMode("pr")}>PR</button>
                <button aria-pressed={matrixMode === "temp"} onClick={() => setMatrixMode("temp")}>Temp</button>
                <button aria-pressed={matrixMode === "dc"} onClick={() => setMatrixMode("dc")}>DC</button>
                <button aria-pressed={matrixMode === "ac"} onClick={() => setMatrixMode("ac")}>AC</button>
              </div>
            </div>
          </div>
          <div style={{padding: "12px 14px", overflow: "auto"}}>
            {["A","B","C"].map(block => (
              <div key={block} style={{marginBottom: 14}}>
                <div style={{fontSize: 11, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.08em", fontWeight: 600, marginBottom: 8}}>
                  Blocco {block} · Sezione {block === "A" ? "Nord" : block === "B" ? "Centro" : "Sud"}
                </div>
                <div style={{display:"grid", gridTemplateColumns: "repeat(6, 1fr)", gap: 6}}>
                  {inverters.filter(i => i.block === block).map(inv => {
                    const v = cellValue(inv, matrixMode);
                    const sel = selInv === inv.id;
                    const cls = `inv-tile ${inv.status} ${sel ? "sel" : ""}`;
                    return (
                      <div key={inv.id} className={cls} onClick={() => setSelInv(inv.id === selInv ? null : inv.id)}>
                        <div className="inv-id">{inv.id}</div>
                        <div className="inv-val mono">{cellFmt(v, matrixMode)}</div>
                        <div className="inv-leds">
                          <span className={`led ${inv.status === "ok" ? "ok" : inv.status === "warn" ? "warn" : inv.status === "crit" ? "crit" : "off"}`} title="Grid"/>
                          <span className={`led ${inv.temp > 70 ? "crit" : inv.temp > 60 ? "warn" : inv.status === "offline" ? "off" : "ok"}`} title="Temp"/>
                          <span className={`led ${inv.status === "offline" ? "off" : inv.pr > 90 ? "ok" : inv.pr > 80 ? "warn" : "crit"}`} title="DC"/>
                          <span className={`led ${inv.status === "offline" ? "off" : "ok"}`} title="AC"/>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
            <div style={{display:"flex", gap: 14, fontSize: 11, color:"var(--fg-muted)", marginTop: 10, paddingTop: 10, borderTop: "1px solid var(--line)"}}>
              <span style={{display:"flex", alignItems:"center", gap: 6}}><span className="led ok"/>Grid</span>
              <span style={{display:"flex", alignItems:"center", gap: 6}}><span className="led ok"/>Temp</span>
              <span style={{display:"flex", alignItems:"center", gap: 6}}><span className="led ok"/>DC</span>
              <span style={{display:"flex", alignItems:"center", gap: 6}}><span className="led ok"/>AC</span>
              <span style={{marginLeft:"auto"}}>6 colonne × 2 righe per blocco</span>
            </div>
          </div>
        </div>

        <div className="panel" style={{minHeight: 0}}>
          <div className="panel-head">
            <div>
              <div className="panel-title">{selected ? `MPPT · ${selected.id}` : "Dettaglio MPPT / Stringhe"}</div>
              <div className="panel-sub">{selected ? `${selected.mppts.length} MPPT · ${selected.mppts.reduce((a,m) => a+m.strings.length, 0)} stringhe` : "Seleziona un inverter"}</div>
            </div>
          </div>
          <div style={{padding: 14, overflowY: "auto"}}>
            {!selected && (
              <div style={{textAlign:"center", color:"var(--fg-muted)", padding: "40px 10px", fontSize: 12}}>
                Clicca una tile della matrice per vedere lo stato dei canali MPPT e delle stringhe collegate.
              </div>
            )}
            {selected && (
              <>
                <div style={{display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap: 6, marginBottom: 14}}>
                  <div style={{background:"var(--bg-2)", border:"1px solid var(--line)", borderRadius: 8, padding: "8px 10px"}}>
                    <div style={{fontSize:10, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.05em"}}>PR</div>
                    <div className="mono" style={{fontSize:16, fontWeight:600, marginTop:2}}>{selected.pr.toFixed(1)}%</div>
                  </div>
                  <div style={{background:"var(--bg-2)", border:"1px solid var(--line)", borderRadius: 8, padding: "8px 10px"}}>
                    <div style={{fontSize:10, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.05em"}}>Temp</div>
                    <div className="mono" style={{fontSize:16, fontWeight:600, marginTop:2, color: selected.temp > 70 ? "var(--crit)" : selected.temp > 60 ? "var(--warn)" : "var(--fg)"}}>{selected.temp.toFixed(0)}°C</div>
                  </div>
                  <div style={{background:"var(--bg-2)", border:"1px solid var(--line)", borderRadius: 8, padding: "8px 10px"}}>
                    <div style={{fontSize:10, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.05em"}}>AC Out</div>
                    <div className="mono" style={{fontSize:16, fontWeight:600, marginTop:2}}>{selected.ac.toFixed(1)} kW</div>
                  </div>
                </div>
                <div style={{fontSize:10, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.05em", fontWeight:600, marginBottom: 8}}>MPPT · Stringhe collegate</div>
                <div style={{display:"flex", flexDirection:"column", gap: 6}}>
                  {selected.mppts.map(m => (
                    <div key={m.n} className="mppt-row">
                      <div className="mppt-head">
                        <span className="mono" style={{fontSize: 10.5, color:"var(--fg-muted)"}}>MPPT</span>
                        <span className="mono" style={{fontSize: 12, fontWeight: 600}}>#{m.n.toString().padStart(2,"0")}</span>
                        <span className="mono" style={{fontSize: 10, color:"var(--fg-dim)", marginLeft:"auto"}}>{m.v.toFixed(0)}V · {m.a.toFixed(1)}A</span>
                      </div>
                      <div className="string-grid">
                        {m.strings.map(s => (
                          <div key={s.n} className={`string-cell ${s.state}`} title={`String ${s.n} · ${s.a.toFixed(1)}A · ${s.state.toUpperCase()}`}>
                            <span className="mono">{s.n}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
                <div style={{display:"flex", gap:10, fontSize: 10, color:"var(--fg-muted)", marginTop: 12, paddingTop: 10, borderTop: "1px solid var(--line)", flexWrap:"wrap"}}>
                  <span style={{display:"flex", alignItems:"center", gap: 4}}><span className="string-cell ok" style={{width:12, height:12}}/>OK</span>
                  <span style={{display:"flex", alignItems:"center", gap: 4}}><span className="string-cell warn" style={{width:12, height:12}}/>Warn</span>
                  <span style={{display:"flex", alignItems:"center", gap: 4}}><span className="string-cell fault" style={{width:12, height:12}}/>Fault</span>
                  <span style={{display:"flex", alignItems:"center", gap: 4}}><span className="string-cell off" style={{width:12, height:12}}/>Off</span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      <style>{`
        .inv-tile {
          border: 1px solid var(--line); border-radius: 7px;
          background: var(--bg-2); padding: 6px 8px;
          display: flex; flex-direction: column; gap: 3px;
          cursor: pointer;
          min-height: 58px;
          position: relative;
          transition: transform 0.12s ease, border-color 0.12s;
        }
        .inv-tile:hover { transform: translateY(-1px); border-color: var(--line-2); }
        .inv-tile.sel { border-color: var(--accent); box-shadow: 0 0 0 2px var(--accent-soft); }
        .inv-tile .inv-id { font-family: var(--mono); font-size: 10px; color: var(--fg-dim); letter-spacing: 0.02em; }
        .inv-tile .inv-val { font-size: 13px; font-weight: 600; letter-spacing: -0.02em; }
        .inv-tile .inv-leds { display: flex; gap: 3px; margin-top: auto; }
        .inv-tile.warn { border-color: color-mix(in oklch, var(--warn) 60%, var(--line)); background: color-mix(in oklch, var(--warn-soft) 40%, var(--bg-2)); }
        .inv-tile.crit { border-color: color-mix(in oklch, var(--crit) 60%, var(--line)); background: color-mix(in oklch, var(--crit-soft) 40%, var(--bg-2)); animation: tile-flash 1.6s ease-in-out infinite; }
        .inv-tile.offline { border-style: dashed; opacity: 0.7; }
        .inv-tile.offline .inv-val { color: var(--fg-muted); }
        @keyframes tile-flash {
          0%, 100% { box-shadow: inset 0 0 0 0 transparent; }
          50% { box-shadow: inset 0 0 0 1px var(--crit); }
        }
        .led {
          width: 8px; height: 8px; border-radius: 2px; display: inline-block;
          background: var(--bg-4);
        }
        .led.ok { background: var(--ok); box-shadow: 0 0 4px color-mix(in oklch, var(--ok) 60%, transparent); }
        .led.warn { background: var(--warn); box-shadow: 0 0 4px color-mix(in oklch, var(--warn) 60%, transparent); }
        .led.crit { background: var(--crit); box-shadow: 0 0 4px color-mix(in oklch, var(--crit) 60%, transparent); animation: led-blink 0.9s ease-in-out infinite; }
        .led.off { background: var(--bg-4); box-shadow: none; }
        @keyframes led-blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.35; }
        }

        .string-row {
          display: grid; grid-template-columns: 34px 1fr 44px 44px auto; align-items: center; gap: 8px;
          padding: 5px 8px; border-radius: 6px; background: var(--bg-2); font-size: 11.5px;
        }
        .string-row.warn { background: color-mix(in oklch, var(--warn-soft) 50%, var(--bg-2)); }
        .string-row.fault { background: color-mix(in oklch, var(--crit-soft) 60%, var(--bg-2)); }
        .string-row.off { opacity: 0.5; }
        .string-n { color: var(--fg-muted); font-size: 10.5px; }
        .string-bar-wrap { height: 6px; background: var(--bg-3); border-radius: 999px; overflow: hidden; }
        .string-bar { height: 100%; background: var(--accent); border-radius: 999px; }
        .string-row.warn .string-bar { background: var(--warn); }
        .string-row.fault .string-bar { background: var(--crit); }
        .string-val { font-size: 10.5px; color: var(--fg-dim); text-align: right; width: 40px; }
        .string-tag {
          font-family: var(--mono); font-size: 9.5px; font-weight: 600;
          padding: 2px 6px; border-radius: 4px; background: var(--ok-soft); color: var(--ok);
          letter-spacing: 0.04em;
        }
        .string-tag.warn { background: var(--warn-soft); color: var(--warn); }
        .string-tag.fault { background: var(--crit-soft); color: var(--crit); }
        .string-tag.off { background: var(--bg-3); color: var(--fg-muted); }

        .mppt-row {
          border: 1px solid var(--line); border-radius: 7px;
          background: var(--bg-2); padding: 7px 9px;
        }
        .mppt-head { display: flex; align-items: center; gap: 6px; margin-bottom: 6px; }
        .string-grid { display: grid; grid-template-columns: repeat(6, 1fr); gap: 3px; }
        .string-cell {
          aspect-ratio: 1; border-radius: 3px;
          display: grid; place-items: center;
          font-size: 9px; font-weight: 600; color: var(--bg);
          background: var(--ok);
        }
        .string-cell.ok { background: var(--ok); }
        .string-cell.warn { background: var(--warn); }
        .string-cell.fault { background: var(--crit); animation: led-blink 0.9s ease-in-out infinite; }
        .string-cell.off { background: var(--bg-4); color: var(--fg-muted); }
      `}</style>
    </div>
  );
}

function PlantKpi({ label, value, color }) {
  return (
    <div style={{
      background:"var(--bg-1)", border:"1px solid var(--line)", borderRadius: 8,
      padding: "10px 12px",
    }}>
      <div style={{fontSize: 10.5, color:"var(--fg-muted)", textTransform:"uppercase", letterSpacing:"0.07em", fontWeight:600}}>{label}</div>
      <div className="mono" style={{fontSize: 22, fontWeight: 600, letterSpacing:"-0.02em", marginTop: 4, color}}>{value}</div>
    </div>
  );
}

window.PlantDetail = PlantDetail;
