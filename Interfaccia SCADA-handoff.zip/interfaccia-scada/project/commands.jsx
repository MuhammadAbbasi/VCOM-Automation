function Commands({ site, commands, setCommands, t }) {
  function toggle(id) {
    setCommands(commands.map(c => c.id === id ? {...c, value: !c.value} : c));
  }
  function bump(id, dir) {
    setCommands(commands.map(c => {
      if (c.id !== id) return c;
      const next = Math.max(c.min, Math.min(c.max, c.value + dir * c.step));
      return {...c, value: next};
    }));
  }

  return (
    <div className="cmd-list">
      {commands.map(c => (
        <div className="cmd" key={c.id}>
          <div>
            <div className="cmd-label">{c.label}</div>
            <div className="cmd-sub">{c.sub}</div>
          </div>
          {c.type === "switch" ? (
            <>
              <div className="cmd-value">
                <span style={{color: c.value ? "var(--ok)" : "var(--fg-muted)"}}>
                  {c.value ? "ON" : "OFF"}
                </span>
              </div>
              <div className="switch" role="switch" aria-checked={c.value} onClick={() => toggle(c.id)}/>
            </>
          ) : (
            <>
              <div className="cmd-value">
                <span className="tabular">{c.value}</span><span className="unit">{c.unit}</span>
              </div>
              <div className="setpoint">
                <button onClick={() => bump(c.id, -1)}><I.minus/></button>
                <div className="setpoint-val">{c.value}</div>
                <button onClick={() => bump(c.id, 1)}><I.plus/></button>
              </div>
            </>
          )}
        </div>
      ))}
      <div className="cmd" style={{borderTop: "1px solid var(--line)", marginTop: 6, paddingTop: 12, gridTemplateColumns: "1fr auto"}}>
        <div className="cmd-sub" style={{color: "var(--fg-muted)"}}>
          {site?.name} · {site?.id}
        </div>
        <div style={{display: "flex", gap: 6}}>
          <button className="btn ghost">Annulla</button>
          <button className="btn primary">{t.confirm_cmd}</button>
        </div>
      </div>
    </div>
  );
}

window.Commands = Commands;
