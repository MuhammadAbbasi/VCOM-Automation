function TrendView({ data, target, chartType, t }) {
  const svgRef = React.useRef(null);
  const [hoverIdx, setHoverIdx] = React.useState(null);
  const [size, setSize] = React.useState({ w: 600, h: 220 });
  const padL = 40, padR = 12, padT = 12, padB = 24;

  React.useEffect(() => {
    const ro = new ResizeObserver(entries => {
      for (const e of entries) {
        const r = e.contentRect;
        setSize({ w: r.width, h: r.height });
      }
    });
    if (svgRef.current && svgRef.current.parentElement) ro.observe(svgRef.current.parentElement);
    return () => ro.disconnect();
  }, []);

  const { w, h } = size;
  const iw = Math.max(40, w - padL - padR);
  const ih = Math.max(40, h - padT - padB);

  const maxV = 160;
  const x = (i) => padL + (i / (data.length - 1)) * iw;
  const y = (v) => padT + ih - (v / maxV) * ih;

  const linePath = data.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`).join(" ");
  const areaPath = linePath + ` L ${x(data.length-1).toFixed(1)} ${y(0)} L ${x(0).toFixed(1)} ${y(0)} Z`;
  const targetPath = target.map((p, i) => `${i === 0 ? "M" : "L"} ${x(i).toFixed(1)} ${y(p.value).toFixed(1)}`).join(" ");

  const hoverPt = hoverIdx != null ? data[hoverIdx] : null;

  // X axis: ticks ogni 4 ore
  const xTicks = [0, 6, 12, 18, 24].map(h => ({ label: `${h.toString().padStart(2,"0")}:00`, idx: Math.round(h * 4) }));
  const yTicks = [0, 40, 80, 120, 160];

  function onMove(e) {
    const rect = svgRef.current.getBoundingClientRect();
    const px = e.clientX - rect.left - padL;
    if (px < 0 || px > iw) { setHoverIdx(null); return; }
    const idx = Math.round((px / iw) * (data.length - 1));
    setHoverIdx(Math.max(0, Math.min(data.length - 1, idx)));
  }

  return (
    <svg ref={svgRef} className="trend-chart" viewBox={`0 0 ${w} ${h}`} onMouseMove={onMove} onMouseLeave={() => setHoverIdx(null)}>
      <defs>
        <linearGradient id="trendGradient" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.35"/>
          <stop offset="100%" stopColor="var(--accent)" stopOpacity="0"/>
        </linearGradient>
      </defs>

      {/* Grid */}
      <g className="trend-grid">
        {yTicks.map(v => (
          <line key={v} x1={padL} x2={padL + iw} y1={y(v)} y2={y(v)}/>
        ))}
      </g>

      {/* Y labels */}
      <g>
        {yTicks.map(v => (
          <text key={v} className="trend-axis-label" x={padL - 6} y={y(v) + 3} textAnchor="end">{v}</text>
        ))}
        <text className="trend-axis-label" x={padL - 6} y={padT + 4} textAnchor="end" fill="var(--fg-dim)">MW</text>
      </g>

      {/* X labels */}
      <g>
        {xTicks.map(tk => (
          <text key={tk.label} className="trend-axis-label" x={x(tk.idx)} y={padT + ih + 14} textAnchor="middle">{tk.label}</text>
        ))}
      </g>

      {/* Target line (dashed) */}
      <path d={targetPath} fill="none" stroke="var(--fg-muted)" strokeWidth="1" strokeDasharray="3 3" opacity="0.55"/>

      {/* Chart body */}
      {chartType === "area" && <path className="trend-area" d={areaPath}/>}
      {chartType !== "candles" && <path className="trend-line" d={linePath}/>}

      {chartType === "candles" && (
        <g>
          {data.map((p, i) => {
            if (i % 2 !== 0) return null; // mezz'ora per leggibilità
            const cw = Math.max(2, iw / (data.length / 2) - 2);
            const cx = x(i);
            const up = p.close >= p.open;
            return (
              <g key={i}>
                <line x1={cx} x2={cx} y1={y(p.high)} y2={y(p.low)} stroke={up ? "var(--ok)" : "var(--crit)"} strokeWidth="1"/>
                <rect
                  x={cx - cw/2}
                  y={y(Math.max(p.open, p.close))}
                  width={cw}
                  height={Math.max(1, Math.abs(y(p.open) - y(p.close)))}
                  className={up ? "trend-candle-up" : "trend-candle-down"}
                  opacity="0.85"
                />
              </g>
            );
          })}
        </g>
      )}

      {/* Hover */}
      {hoverPt && (
        <g>
          <line className="trend-hover-line" x1={x(hoverIdx)} x2={x(hoverIdx)} y1={padT} y2={padT + ih}/>
          {chartType !== "candles" && <circle className="trend-hover-dot" cx={x(hoverIdx)} cy={y(hoverPt.value)} r="4"/>}
          <g transform={`translate(${Math.min(x(hoverIdx) + 8, w - 130)}, ${padT + 6})`}>
            <rect x="0" y="0" width="120" height="52" rx="6" fill="var(--bg-3)" stroke="var(--line-2)"/>
            <text x="8" y="16" fontSize="10.5" fill="var(--fg-muted)" fontFamily="var(--mono)">{`${Math.floor(hoverPt.hour).toString().padStart(2,"0")}:${Math.round((hoverPt.hour%1)*60).toString().padStart(2,"0")}`}</text>
            <text x="8" y="32" fontSize="13" fill="var(--fg)" fontFamily="var(--mono)" fontWeight="600">{hoverPt.value.toFixed(1)} <tspan fill="var(--fg-muted)" fontSize="10">MW</tspan></text>
            <text x="8" y="46" fontSize="10" fill="var(--fg-muted)" fontFamily="var(--mono)">{t.target}: {target[hoverIdx].value.toFixed(1)} MW</text>
          </g>
        </g>
      )}
    </svg>
  );
}

window.TrendView = TrendView;
