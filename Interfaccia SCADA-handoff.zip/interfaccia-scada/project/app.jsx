const { SITES, ALARMS, TRENDS, COMMANDS_DEFAULT, STRINGS } = window.SCADA_DATA;

// Default tweakable config
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "chartType": "area",
  "theme": "dark",
  "lang": "it",
  "accentHue": 140
}/*EDITMODE-END*/;

function Sparkline({ values, color = "currentColor" }) {
  const w = 74, h = 26;
  const max = Math.max(...values), min = Math.min(...values);
  const rng = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * w;
    const y = h - ((v - min) / rng) * h;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return (
    <svg className="sparkline" viewBox={`0 0 ${w} ${h}`}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function App() {
  // Tweakable state
  const [theme, setTheme] = React.useState(TWEAK_DEFAULTS.theme);
  const [lang, setLang] = React.useState(TWEAK_DEFAULTS.lang);
  const [chartType, setChartType] = React.useState(TWEAK_DEFAULTS.chartType);
  const [accentHue, setAccentHue] = React.useState(TWEAK_DEFAULTS.accentHue);
  const [tweaksOpen, setTweaksOpen] = React.useState(false);
  const [editAvailable, setEditAvailable] = React.useState(false);

  // App state
  const [alarms, setAlarms] = React.useState(ALARMS);
  const [alarmFilter, setAlarmFilter] = React.useState("all");
  const [selectedSite, setSelectedSite] = React.useState("NAP-12"); // un sito critico
  const [mapStatusFilter, setMapStatusFilter] = React.useState("all");
  const [nav, setNav] = React.useState("map");
  const [view, setView] = React.useState("fleet"); // fleet | plant
  const [commands, setCommands] = React.useState(COMMANDS_DEFAULT);
  const [now, setNow] = React.useState(new Date());

  const t = STRINGS[lang];
  const site = SITES.find(s => s.id === selectedSite);

  // apply theme + accent
  React.useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  React.useEffect(() => {
    const isLight = theme === "light";
    const L = isLight ? 0.62 : 0.78;
    const C = isLight ? 0.18 : 0.17;
    const root = document.documentElement;
    root.style.setProperty("--accent", `oklch(${L} ${C} ${accentHue})`);
    root.style.setProperty("--accent-soft", `oklch(${L} ${C} ${accentHue} / ${isLight ? 0.13 : 0.15})`);
  }, [accentHue, theme]);

  // Tick clock
  React.useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Tweaks host protocol
  React.useEffect(() => {
    function handle(e) {
      if (!e.data || typeof e.data !== "object") return;
      if (e.data.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data.type === "__deactivate_edit_mode") setTweaksOpen(false);
    }
    window.addEventListener("message", handle);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    setEditAvailable(true);
    return () => window.removeEventListener("message", handle);
  }, []);

  function persist(key, val) {
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [key]: val } }, "*");
  }

  function ackAlarm(id) {
    setAlarms(alarms.map(a => a.id === id ? {...a, ack: true} : a));
  }

  // Live "tick" indicator for kpi values (subtle)
  const [kpiTick, setKpiTick] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setKpiTick(k => k + 1), 4000);
    return () => clearInterval(id);
  }, []);

  // KPIs derived
  const instantPowerMW = 87.4 + Math.sin(kpiTick * 0.6) * 1.8;
  const energyTodayMWh = 612.8 + kpiTick * 0.1;
  const availability = 94.2;
  const irradiance = 784 + Math.sin(kpiTick * 0.4) * 12;
  const co2 = 284.6;

  const sparkBase = TRENDS.fleet.slice(-24).map(p => p.value);

  // Nav items
  const NAV = [
    { id: "overview", label: t.overview, icon: <I.grid/>, kbd: "G" },
    { id: "map",      label: t.map,      icon: <I.map/>,  kbd: "M" },
    { id: "chart",    label: t.analytics,icon: <I.chart/>,kbd: "A" },
    { id: "alarms",   label: t.alarms,   icon: <I.bell/>, badge: alarms.filter(a=>!a.ack && a.sev==="crit").length || null },
    { id: "ctrl",     label: t.commands, icon: <I.sliders/>,kbd: "C" },
    { id: "mx",       label: t.maintenance,icon: <I.wrench/>},
    { id: "rep",      label: t.reports,  icon: <I.doc/>},
    { id: "set",      label: t.settings, icon: <I.gear/>},
  ];

  // Asset tree groups
  const assetGroups = [
    { key: "nord",  label: t.nord,   ids: ["MIL-01","TUR-02","VRN-03","BOL-04","VEN-05","GEN-06"] },
    { key: "centro",label: t.centro, ids: ["BLN-07","FIR-08","ANC-09","ROM-10","AQL-11"] },
    { key: "sud",   label: t.sud,    ids: ["NAP-12","BAR-13","TAR-14","CSZ-15","REG-16","PAL-17","CAT-18","CAG-19","SAS-20"] },
  ];
  const [expanded, setExpanded] = React.useState({ nord: true, centro: true, sud: true });

  return (
    <div className="app">
      {/* === Topbar === */}
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark"/>
          <div>Helios Control</div>
        </div>
        <div className="crumbs">
          <span>{t.impianti}</span>
          <span className="sep">›</span>
          <strong>{t.all_sites}</strong>
          {site && (
            <>
              <span className="sep">›</span>
              <strong>{site.name}</strong>
              <span className="mono" style={{color:"var(--fg-muted)", marginLeft:4}}>{site.id}</span>
            </>
          )}
        </div>

        <div className="topbar-spacer"/>

        <div className="pill" style={{width: 220, paddingLeft: 10}}>
          <I.search/>
          <span style={{color:"var(--fg-muted)"}}>{t.search}</span>
          <span className="mono" style={{marginLeft:"auto", color:"var(--fg-muted)", fontSize:10}}>⌘K</span>
        </div>

        <div className="topbar-right">
          <div className="pill live"><span className="dot"/><span className="mono" style={{color:"var(--fg)"}}>{t.live}</span></div>
          <div className="pill mono" title="Orario UTC+1">{now.toLocaleTimeString(lang === "it" ? "it-IT" : "en-GB", { hour12: false })}</div>
          <div className="seg" role="group" aria-label="theme">
            <button aria-pressed={theme === "dark"} onClick={() => { setTheme("dark"); persist("theme","dark"); }}><I.moon/></button>
            <button aria-pressed={theme === "light"} onClick={() => { setTheme("light"); persist("theme","light"); }}><I.sun/></button>
          </div>
          <div className="seg" role="group" aria-label="lang">
            <button aria-pressed={lang === "it"} onClick={() => { setLang("it"); persist("lang","it"); }}>IT</button>
            <button aria-pressed={lang === "en"} onClick={() => { setLang("en"); persist("lang","en"); }}>EN</button>
          </div>
        </div>
      </header>

      {/* === Sidebar === */}
      <nav className="sidebar">
        <div className="side-section">
          {NAV.map(item => (
            <div
              key={item.id}
              className="nav-item"
              aria-current={nav === item.id}
              onClick={() => setNav(item.id)}
            >
              {item.icon}
              <span>{item.label}</span>
              {item.badge ? <span className="badge mono">{item.badge}</span> : item.kbd ? <span className="kbd">{item.kbd}</span> : null}
            </div>
          ))}
        </div>

        <div className="side-section asset-tree">
          <div className="side-label">{t.impianti} · 20</div>
          {assetGroups.map(g => (
            <div key={g.key}>
              <div className="group" onClick={() => setExpanded({...expanded, [g.key]: !expanded[g.key]})}>
                <I.chev style={{transform: expanded[g.key] ? "rotate(90deg)" : "none", transition:"transform .15s"}}/>
                <span>{g.label}</span>
                <span className="count">{g.ids.length}</span>
              </div>
              {expanded[g.key] && g.ids.map(id => {
                const s = SITES.find(x => x.id === id);
                return (
                  <div key={id} className="asset" onClick={() => setSelectedSite(id)} style={{
                    background: selectedSite === id ? "var(--bg-3)" : "transparent",
                    color: selectedSite === id ? "var(--fg)" : undefined,
                  }}>
                    <span className={`state ${s.status === "ok" ? "" : s.status}`}/>
                    <span style={{flex:1, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap"}}>{s.name}</span>
                    <span className="mono" style={{fontSize:10, color:"var(--fg-muted)"}}>{s.capacity.toFixed(1)}</span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </nav>

      {/* === Main === */}
      <main className="main">
        {view === "plant" ? (
          <PlantDetail site={site} onBack={() => setView("fleet")} t={t}/>
        ) : (
        <>
        <div className="main-header">
          <div>
            <div className="main-title">{t.main_title}</div>
            <div className="main-sub">{t.main_sub}</div>
          </div>
          <div style={{flex: 1}}/>
          <button className="btn" onClick={() => setView("plant")}>Apri {site?.name} →</button>
          <div className="seg">
            <button aria-pressed={mapStatusFilter === "all"} onClick={() => setMapStatusFilter("all")}>{t.filter_all}</button>
            <button aria-pressed={mapStatusFilter === "ok"} onClick={() => setMapStatusFilter("ok")}>{t.status_ok}</button>
            <button aria-pressed={mapStatusFilter === "warn"} onClick={() => setMapStatusFilter("warn")}>{t.status_warn}</button>
            <button aria-pressed={mapStatusFilter === "crit"} onClick={() => setMapStatusFilter("crit")}>{t.status_crit}</button>
          </div>
        </div>

        {/* KPIs */}
        <div className="kpi-row">
          <div className="kpi">
            <div className="k-label">{t.kpi_power}</div>
            <div className="k-value">{instantPowerMW.toFixed(1)}<span className="k-unit">MW</span></div>
            <div className="k-delta up"><I.up/> +2.4% vs 1h</div>
            <Sparkline values={sparkBase}/>
          </div>
          <div className="kpi">
            <div className="k-label">{t.kpi_energy}</div>
            <div className="k-value">{energyTodayMWh.toFixed(0)}<span className="k-unit">MWh</span></div>
            <div className="k-delta up"><I.up/> +8.1% vs ieri</div>
            <Sparkline values={sparkBase.map((v,i) => v * (1 + i*0.03))}/>
          </div>
          <div className="kpi">
            <div className="k-label">{t.kpi_fleet}</div>
            <div className="k-value">{availability.toFixed(1)}<span className="k-unit">%</span></div>
            <div className="k-delta down"><I.down/> −0.6% vs 7d</div>
            <Sparkline values={[95,95,94.8,94.2,94,94.1,94.3,94.2,94.2,94.5,94.1,94.2]}/>
          </div>
          <div className="kpi">
            <div className="k-label">{t.kpi_irr}</div>
            <div className="k-value">{irradiance.toFixed(0)}<span className="k-unit">W/m²</span></div>
            <div className="k-delta up"><I.up/> Clear sky</div>
            <Sparkline values={sparkBase.map((v,i) => 700 + Math.sin(i*0.4)*80)}/>
          </div>
          <div className="kpi">
            <div className="k-label">{t.kpi_co2}</div>
            <div className="k-value">{co2.toFixed(1)}<span className="k-unit">t</span></div>
            <div className="k-delta up"><I.up/> +12.3 oggi</div>
            <Sparkline values={sparkBase.map((v,i) => v * 0.7 + i)}/>
          </div>
        </div>

        {/* Workspace: mappa + (trend sopra, comandi sotto) */}
        <div className="workspace">
          <div className="panel">
            <div className="panel-head">
              <div>
                <div className="panel-title">{t.map}</div>
                <div className="panel-sub">20 {t.impianti.toLowerCase()} · {SITES.reduce((a,s) => a+s.capacity, 0).toFixed(1)} MWp</div>
              </div>
              <div className="right">
                <button className="chip"><I.filter/> {t.filter_all}</button>
              </div>
            </div>
            <MapView
              sites={SITES}
              selectedId={selectedSite}
              onSelect={setSelectedSite}
              statusFilter={mapStatusFilter}
              t={t}
            />
          </div>

          <div className="right-col">
            <div className="panel trend-panel">
              <div className="panel-head">
                <div>
                  <div className="panel-title">{t.chart_title}</div>
                  <div className="panel-sub">{t.chart_sub}</div>
                </div>
                <div className="right">
                  <div className="seg">
                    <button aria-pressed={chartType === "line"} onClick={() => { setChartType("line"); persist("chartType","line"); }}>{t.line}</button>
                    <button aria-pressed={chartType === "area"} onClick={() => { setChartType("area"); persist("chartType","area"); }}>{t.area}</button>
                    <button aria-pressed={chartType === "candles"} onClick={() => { setChartType("candles"); persist("chartType","candles"); }}>{t.candles}</button>
                  </div>
                </div>
              </div>
              <div style={{padding: "4px 8px 6px 6px", display:"flex", gap: 14, fontSize: 11, color:"var(--fg-dim)"}}>
                <div style={{display:"flex", alignItems:"center", gap: 6}}>
                  <span style={{width: 12, height: 2, background: "var(--accent)", borderRadius: 2}}/>
                  <span>{t.fleet}</span>
                </div>
                <div style={{display:"flex", alignItems:"center", gap: 6}}>
                  <span style={{width: 12, height: 0, borderTop: "1px dashed var(--fg-muted)"}}/>
                  <span>{t.target}</span>
                </div>
              </div>
              <div className="trend-chart-wrap" style={{flex: 1, minHeight: 0}}>
                <TrendView data={TRENDS.fleet} target={TRENDS.target} chartType={chartType} t={t}/>
              </div>
            </div>

            <div className="panel commands-panel">
              <div className="panel-head">
                <div>
                  <div className="panel-title">{t.cmd_title.replace("%s", site?.name || "—")}</div>
                  <div className="panel-sub">{t.cmd_sub}</div>
                </div>
                <div className="right">
                  <span className="mono" style={{fontSize: 11, color: "var(--fg-muted)"}}>{site?.id}</span>
                </div>
              </div>
              <div style={{flex:1, minHeight: 0, overflow: "auto"}}>
                <Commands site={site} commands={commands} setCommands={setCommands} t={t}/>
              </div>
            </div>
          </div>
        </div>
        </>
        )}
      </main>

      {/* === Alarm Rail === */}
      <AlarmRail alarms={alarms} ackAlarm={ackAlarm} filter={alarmFilter} setFilter={setAlarmFilter} t={t} SITES={SITES}/>

      {/* === Tweaks panel === */}
      <div className="tweaks" data-open={tweaksOpen}>
        <h4>{t.tweaks} <span className="tag">live</span></h4>
        <div className="tweaks-body">
          <div className="tweak-group">
            <label>{t.chart_type}</label>
            <div className="tweak-seg">
              <button aria-pressed={chartType === "line"} onClick={() => { setChartType("line"); persist("chartType","line"); }}>{t.line}</button>
              <button aria-pressed={chartType === "area"} onClick={() => { setChartType("area"); persist("chartType","area"); }}>{t.area}</button>
              <button aria-pressed={chartType === "candles"} onClick={() => { setChartType("candles"); persist("chartType","candles"); }}>{t.candles}</button>
            </div>
          </div>
          <div className="tweak-group">
            <label>{t.theme}</label>
            <div className="tweak-seg">
              <button aria-pressed={theme === "dark"} onClick={() => { setTheme("dark"); persist("theme","dark"); }}>Dark</button>
              <button aria-pressed={theme === "light"} onClick={() => { setTheme("light"); persist("theme","light"); }}>Light</button>
            </div>
          </div>
          <div className="tweak-group">
            <label>{t.lang}</label>
            <div className="tweak-seg">
              <button aria-pressed={lang === "it"} onClick={() => { setLang("it"); persist("lang","it"); }}>Italiano</button>
              <button aria-pressed={lang === "en"} onClick={() => { setLang("en"); persist("lang","en"); }}>English</button>
            </div>
          </div>
          <div className="tweak-group">
            <label>Accent hue · {accentHue}°</label>
            <input type="range" min="0" max="360" step="5" value={accentHue}
              onChange={(e) => { const v = +e.target.value; setAccentHue(v); persist("accentHue", v); }}
              style={{width: "100%"}}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
