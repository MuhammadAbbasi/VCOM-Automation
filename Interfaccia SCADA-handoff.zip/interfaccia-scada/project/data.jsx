// Sintesi dati impianti FV — coordinate italiane normalizzate in 0..1
// Cartografia: bounding box Italia approssimato
// x: 6.5E..18.5E, y: 47N..36N (flipped)
const SITES = [
  // Nord
  { id: "MIL-01",  name: "Cascina Solare",   city: "Milano",   lat: 45.46, lon: 9.19,  capacity: 5.8, status: "ok",   panels: 14220, commissioned: 2021 },
  { id: "TUR-02",  name: "Pianura Nord",     city: "Torino",   lat: 45.07, lon: 7.68,  capacity: 4.2, status: "ok",   panels: 10540, commissioned: 2020 },
  { id: "VRN-03",  name: "Valle Sole",       city: "Verona",   lat: 45.44, lon: 10.99, capacity: 6.1, status: "warn", panels: 15310, commissioned: 2022 },
  { id: "BOL-04",  name: "Monte Alto",       city: "Bolzano",  lat: 46.49, lon: 11.35, capacity: 3.2, status: "ok",   panels: 8010,  commissioned: 2019 },
  { id: "VEN-05",  name: "Laguna East",      city: "Venezia",  lat: 45.44, lon: 12.32, capacity: 2.8, status: "ok",   panels: 7020,  commissioned: 2021 },
  { id: "GEN-06",  name: "Ponente 1",        city: "Genova",   lat: 44.41, lon: 8.93,  capacity: 4.5, status: "crit", panels: 11300, commissioned: 2022 },
  // Centro
  { id: "BLN-07",  name: "Pianoro",          city: "Bologna",  lat: 44.49, lon: 11.34, capacity: 5.4, status: "ok",   panels: 13500, commissioned: 2020 },
  { id: "FIR-08",  name: "Toscana Ovest",    city: "Firenze",  lat: 43.77, lon: 11.25, capacity: 7.2, status: "warn", panels: 18000, commissioned: 2023 },
  { id: "ANC-09",  name: "Adriatico",        city: "Ancona",   lat: 43.62, lon: 13.52, capacity: 3.9, status: "ok",   panels: 9700,  commissioned: 2021 },
  { id: "ROM-10",  name: "Agro Romano",      city: "Roma",     lat: 41.90, lon: 12.49, capacity: 9.8, status: "ok",   panels: 24500, commissioned: 2022 },
  { id: "AQL-11",  name: "Altopiano",        city: "L'Aquila", lat: 42.35, lon: 13.40, capacity: 4.6, status: "ok",   panels: 11600, commissioned: 2020 },
  // Sud
  { id: "NAP-12",  name: "Vesuvio Sud",      city: "Napoli",   lat: 40.85, lon: 14.27, capacity: 6.5, status: "crit", panels: 16400, commissioned: 2023 },
  { id: "BAR-13",  name: "Tavoliere",        city: "Bari",     lat: 41.12, lon: 16.87, capacity: 12.4,panels: 31000, status: "ok",   commissioned: 2022 },
  { id: "TAR-14",  name: "Salento Alto",     city: "Taranto",  lat: 40.47, lon: 17.24, capacity: 10.1,panels: 25300, status: "warn", commissioned: 2021 },
  { id: "CSZ-15",  name: "Sila Est",         city: "Cosenza",  lat: 39.30, lon: 16.25, capacity: 5.0, status: "ok",   panels: 12500, commissioned: 2020 },
  { id: "REG-16",  name: "Stretto",          city: "Reggio C.",lat: 38.11, lon: 15.65, capacity: 4.4, status: "ok",   panels: 11000, commissioned: 2019 },
  // Isole
  { id: "PAL-17",  name: "Conca d'Oro",      city: "Palermo",  lat: 38.12, lon: 13.36, capacity: 8.7, status: "warn", panels: 21800, commissioned: 2022 },
  { id: "CAT-18",  name: "Etna South",       city: "Catania",  lat: 37.50, lon: 15.09, capacity: 11.2,panels: 28000, status: "ok",   commissioned: 2023 },
  { id: "CAG-19",  name: "Campidano",        city: "Cagliari", lat: 39.22, lon: 9.12,  capacity: 9.1, status: "ok",   panels: 22800, commissioned: 2022 },
  { id: "SAS-20",  name: "Gallura",          city: "Sassari",  lat: 40.73, lon: 8.56,  capacity: 4.7, status: "ok",   panels: 11700, commissioned: 2021 },
];

const ALARMS = [
  { id: "A-2416", sev: "crit", site: "GEN-06", msg: "Inverter #3 · Sovratensione DC 1180V", detail: "String 12–14 offline", time: "14:27:04", ack: false },
  { id: "A-2415", sev: "crit", site: "NAP-12", msg: "Tracker Zone B · Perdita comunicazione", detail: "3 tracker non rispondono", time: "14:25:48", ack: false },
  { id: "A-2414", sev: "crit", site: "NAP-12", msg: "Trasformatore T2 · Temperatura olio 92°C", detail: "Soglia 88°C superata", time: "14:19:12", ack: false },
  { id: "A-2413", sev: "warn", site: "VRN-03", msg: "String 7 · Produzione −18% vs atteso", detail: "Possibile sporcamento", time: "13:52:30", ack: false },
  { id: "A-2412", sev: "warn", site: "FIR-08", msg: "Inverter #1 · Derating termico attivo", detail: "Temp. 68°C", time: "13:44:15", ack: false },
  { id: "A-2411", sev: "warn", site: "TAR-14", msg: "MPPT 4 · Tensione sotto soglia", detail: "Vmpp 412V, min 450V", time: "13:22:07", ack: true },
  { id: "A-2410", sev: "warn", site: "PAL-17", msg: "Meteo · Vento 78 km/h (soglia 70)", detail: "Posizione sicurezza attivata", time: "12:58:44", ack: false },
  { id: "A-2409", sev: "info", site: "ROM-10", msg: "Manutenzione programmata · String 22", detail: "Sostituzione modulo #18 completata", time: "12:31:22", ack: true },
  { id: "A-2408", sev: "info", site: "BAR-13", msg: "Firmware inverter aggiornato", detail: "v4.2.1 → v4.2.3", time: "11:47:11", ack: true },
  { id: "A-2407", sev: "info", site: "CAG-19", msg: "Nuovo set-point produzione attivo", detail: "Limite di rete 85%", time: "11:12:00", ack: true },
];

// Trend series: ultime 24h, granularità 15min = 96 punti
function genTrend(seed) {
  const pts = [];
  let t = 6 * 4; // parte dalle 6 del mattino
  const start = Date.now() - 24 * 3600 * 1000;
  for (let i = 0; i < 96; i++) {
    const hour = (i * 15) / 60;
    // curva solare gaussiana centrata sulle 13
    const center = 13;
    const spread = 4.2;
    const gauss = Math.exp(-Math.pow((hour - center) / spread, 2));
    const cloud = 0.82 + 0.18 * Math.sin(i * 0.4 + seed) * Math.sin(i * 0.13 + seed * 2);
    const noise = (Math.sin(i * 1.3 + seed * 3) + Math.sin(i * 2.7 + seed)) * 0.03;
    let p = Math.max(0, gauss * cloud + noise);
    // saturazione centrale
    if (p > 0.95) p = 0.95 + (p - 0.95) * 0.3;
    pts.push({
      t: start + i * 15 * 60 * 1000,
      hour,
      value: p * 148, // 148 MW picco flotta
      // candle fields
      open: p * 148,
      close: Math.max(0, (p + noise) * 148),
      high: Math.max(0, (p + Math.abs(noise) * 2) * 148),
      low: Math.max(0, (p - Math.abs(noise) * 1.6) * 148),
    });
  }
  // ricalcola open/close/high/low come rolling window
  for (let i = 0; i < pts.length; i++) {
    const prev = i > 0 ? pts[i-1].value : pts[i].value;
    const cur = pts[i].value;
    pts[i].open = prev;
    pts[i].close = cur;
    pts[i].high = Math.max(prev, cur) * (1 + Math.abs(Math.sin(i*1.7+seed))*0.02);
    pts[i].low = Math.min(prev, cur) * (1 - Math.abs(Math.sin(i*2.3+seed))*0.02);
  }
  return pts;
}

const TRENDS = {
  fleet: genTrend(0.7),
  target: genTrend(0.1).map(p => ({...p, value: p.value * 1.05})),
};

// Commands per sito selezionato (default)
const COMMANDS_DEFAULT = [
  { id: "inv-run", type: "switch", label: "Inverter principale", sub: "3 × 1500V DC", value: true },
  { id: "trk-auto", type: "switch", label: "Tracker auto-sun", sub: "Azimut/elevazione automatici", value: true },
  { id: "grid-inject", type: "switch", label: "Iniezione in rete", sub: "Connessione AT 30kV", value: true },
  { id: "pwr-limit", type: "setpoint", label: "Limite potenza attiva", sub: "Range 0–100%", value: 85, min: 0, max: 100, step: 5, unit: "%" },
  { id: "setp-cosphi", type: "setpoint", label: "Cosφ set-point", sub: "Fattore di potenza", value: 98, min: 80, max: 100, step: 1, unit: "·0.01" },
  { id: "night-mode", type: "switch", label: "Modalità notturna", sub: "Consumo servizi ridotto", value: false },
];

// Strings: IT / EN
const STRINGS = {
  it: {
    overview: "Panoramica", map: "Mappa impianti", analytics: "Analisi", alarms: "Allarmi",
    commands: "Comandi", maintenance: "Manutenzione", reports: "Report", settings: "Impostazioni",
    impianti: "Impianti", all_sites: "Tutti i siti", nord: "Nord", centro: "Centro", sud: "Sud e Isole",
    kpi_power: "Potenza istantanea", kpi_energy: "Energia oggi", kpi_fleet: "Disponibilità flotta",
    kpi_irr: "Irraggiamento medio", kpi_co2: "CO₂ evitata",
    main_title: "Flotta solare · Italia", main_sub: "20 impianti · 130,2 MWp installati",
    chart_title: "Produzione flotta · ultime 24h", chart_sub: "Aggiornato ogni 15s",
    cmd_title: "Comandi · %s", cmd_sub: "Richiede conferma operatore",
    alarms_title: "Allarmi attivi", critical: "Critici", warning: "Warning", info: "Info",
    grp_crit: "Critici · Intervento immediato", grp_warn: "Warning · Da verificare", grp_info: "Info · Ultime 24h",
    ack: "ACK", ackd: "Acknowledged", filter_all: "Tutti", attivi: "Attivi",
    connected: "Sistema connesso", live: "LIVE", theme: "Tema", lang: "Lingua",
    search: "Cerca impianti, tag, allarmi…",
    chart_type: "Tipo grafico", line: "Linea", area: "Area", candles: "Candele",
    tweaks: "Tweaks",
    confirm_cmd: "Conferma",
    status_ok: "Nominale", status_warn: "Warning", status_crit: "Critico",
    capacity: "Capacità", today: "Oggi", production: "Produzione", irr: "Irraggiamento",
    fleet: "Flotta", target: "Atteso",
    apply: "Applica",
  },
  en: {
    overview: "Overview", map: "Asset map", analytics: "Analytics", alarms: "Alarms",
    commands: "Commands", maintenance: "Maintenance", reports: "Reports", settings: "Settings",
    impianti: "Sites", all_sites: "All sites", nord: "North", centro: "Center", sud: "South & Islands",
    kpi_power: "Instant power", kpi_energy: "Energy today", kpi_fleet: "Fleet availability",
    kpi_irr: "Avg. irradiance", kpi_co2: "CO₂ avoided",
    main_title: "Solar fleet · Italy", main_sub: "20 sites · 130.2 MWp installed",
    chart_title: "Fleet production · last 24h", chart_sub: "Refreshed every 15s",
    cmd_title: "Commands · %s", cmd_sub: "Requires operator confirmation",
    alarms_title: "Active alarms", critical: "Critical", warning: "Warning", info: "Info",
    grp_crit: "Critical · Immediate action", grp_warn: "Warning · Review", grp_info: "Info · Last 24h",
    ack: "ACK", ackd: "Acknowledged", filter_all: "All", attivi: "Active",
    connected: "System connected", live: "LIVE", theme: "Theme", lang: "Language",
    search: "Search sites, tags, alarms…",
    chart_type: "Chart type", line: "Line", area: "Area", candles: "Candles",
    tweaks: "Tweaks",
    confirm_cmd: "Confirm",
    status_ok: "Nominal", status_warn: "Warning", status_crit: "Critical",
    capacity: "Capacity", today: "Today", production: "Production", irr: "Irradiance",
    fleet: "Fleet", target: "Target",
    apply: "Apply",
  }
};

window.SCADA_DATA = { SITES, ALARMS, TRENDS, COMMANDS_DEFAULT, STRINGS };
