function AlarmRail({ alarms, ackAlarm, filter, setFilter, t, SITES }) {
  const counts = {
    crit: alarms.filter(a => a.sev === "crit" && !a.ack).length,
    warn: alarms.filter(a => a.sev === "warn" && !a.ack).length,
    info: alarms.filter(a => a.sev === "info" && !a.ack).length,
  };
  const filtered = filter === "all" ? alarms : alarms.filter(a => a.sev === filter);
  const groups = [
    { key: "crit", label: t.grp_crit, items: filtered.filter(a => a.sev === "crit") },
    { key: "warn", label: t.grp_warn, items: filtered.filter(a => a.sev === "warn") },
    { key: "info", label: t.grp_info, items: filtered.filter(a => a.sev === "info") },
  ];

  return (
    <aside className="alarm-rail">
      <div className="alarm-head">
        <h3>{t.alarms_title}</h3>
        <div className="sev-row">
          <div className={`sev crit`} aria-pressed={filter === "crit"} onClick={() => setFilter(filter === "crit" ? "all" : "crit")}>
            <div className="sev-n">{counts.crit}</div>
            <div className="sev-l">{t.critical}</div>
          </div>
          <div className={`sev warn`} aria-pressed={filter === "warn"} onClick={() => setFilter(filter === "warn" ? "all" : "warn")}>
            <div className="sev-n">{counts.warn}</div>
            <div className="sev-l">{t.warning}</div>
          </div>
          <div className={`sev info`} aria-pressed={filter === "info"} onClick={() => setFilter(filter === "info" ? "all" : "info")}>
            <div className="sev-n">{counts.info}</div>
            <div className="sev-l">{t.info}</div>
          </div>
        </div>
      </div>

      <div className="alarm-list">
        {groups.map(g => (
          g.items.length > 0 && (
            <div key={g.key}>
              <div className="alarm-group-head">
                <span>{g.label}</span>
                <span className="count mono">{g.items.length}</span>
              </div>
              {g.items.map(a => {
                const site = SITES.find(s => s.id === a.site);
                return (
                  <div key={a.id} className={`alarm-item ${a.sev} ${a.ack ? "ack" : ""}`}>
                    <div className="bar"/>
                    <div className="alarm-body">
                      <div className="alarm-msg">{a.msg}</div>
                      <div className="alarm-meta">
                        <span className="mono">{a.id}</span>
                        <span className="dot"/>
                        <span>{site ? `${site.name}` : a.site}</span>
                        <span className="dot"/>
                        <span style={{color: "var(--fg-dim)"}}>{a.detail}</span>
                      </div>
                    </div>
                    <div className="alarm-actions">
                      <div className="alarm-time">{a.time}</div>
                      {!a.ack ? (
                        <button className="alarm-ack" onClick={(e) => { e.stopPropagation(); ackAlarm(a.id); }}>{t.ack}</button>
                      ) : (
                        <div className="alarm-time" style={{color: "var(--ok)"}}>✓ {t.ackd}</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )
        ))}
        {filtered.length === 0 && <div className="empty">—</div>}
      </div>
    </aside>
  );
}

window.AlarmRail = AlarmRail;
