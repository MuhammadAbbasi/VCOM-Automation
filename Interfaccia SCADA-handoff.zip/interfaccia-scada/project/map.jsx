// Mappa Italia stilizzata — path SVG accurato derivato da dataset geografico semplificato
// viewBox 1000x1000.

function ll2xy(lat, lon) {
  const minLon = 6.5, maxLon = 18.6;
  const minLat = 35.5, maxLat = 47.1;
  const x = ((lon - minLon) / (maxLon - minLon)) * 1000;
  const y = ((maxLat - lat) / (maxLat - minLat)) * 1000;
  return [x, y];
}

// Path Italia — costruito manualmente seguendo landmark geografici reali.
// viewBox 1000x1000. Forma riconoscibile: penisola con "tacco", "punta", Po valley,
// Sicilia a forma triangolare sotto la punta, Sardegna a ovest.

// Path silhouette Italia — proiettata da lat/lon reali via Natural Earth semplificato
const ITALY_PATH = "M 129.9 294.2 L 100.8 285.8 L 78.7 270.8 L 51.2 241.7 L 47.2 208.3 L 63.0 175.0 L 70.9 145.8 L 129.9 112.5 L 181.1 104.2 L 212.6 100.0 L 244.1 87.5 L 295.3 66.7 L 334.6 37.5 L 362.2 29.2 L 401.6 25.0 L 468.5 20.8 L 515.7 54.2 L 566.9 62.5 L 586.6 100.0 L 594.5 126.7 L 578.7 129.2 L 543.3 129.2 L 496.1 145.8 L 484.3 165.0 L 476.4 183.3 L 478.7 201.7 L 488.2 229.2 L 496.1 258.3 L 574.8 279.2 L 602.4 312.5 L 622.0 358.3 L 653.5 400.0 L 673.2 425.0 L 704.7 450.0 L 763.8 445.8 L 787.4 450.0 L 815.0 454.2 L 862.2 466.7 L 893.7 504.2 L 925.2 537.5 L 960.6 579.2 L 968.5 595.8 L 937.0 612.5 L 893.7 600.0 L 866.1 570.8 L 838.6 570.8 L 815.0 616.7 L 858.3 658.3 L 862.2 700.0 L 826.8 729.2 L 783.5 779.2 L 759.8 775.0 L 744.1 754.2 L 767.7 712.5 L 759.8 670.8 L 728.3 620.8 L 700.8 604.2 L 689.0 587.5 L 657.5 562.5 L 618.1 541.7 L 586.6 508.3 L 535.4 504.2 L 484.3 504.2 L 437.0 429.2 L 401.6 408.3 L 381.9 383.3 L 354.3 362.5 L 338.6 325.0 L 318.9 287.5 L 303.1 275.0 L 283.5 266.7 L 236.2 250.0 L 189.0 241.7 L 157.5 258.3 L 129.9 294.2 Z";

const HEEL_PATH = "";

const SICILY_PATH = "M 496.1 779.2 L 519.7 766.7 L 559.1 758.3 L 594.5 758.3 L 629.9 770.8 L 677.2 762.5 L 704.7 754.2 L 712.6 766.7 L 744.1 754.2 L 716.5 812.5 L 700.8 850.0 L 689.0 883.3 L 669.3 887.5 L 641.7 883.3 L 602.4 879.2 L 566.9 866.7 L 523.6 850.0 L 492.1 812.5 L 496.1 779.2 Z";

const SARDINIA_PATH = "M 157.5 504.2 L 169.3 525.0 L 185.0 537.5 L 216.5 537.5 L 244.1 533.3 L 263.8 533.3 L 275.6 558.3 L 275.6 604.2 L 263.8 645.8 L 263.8 679.2 L 228.3 675.0 L 204.7 695.8 L 173.2 683.3 L 173.2 645.8 L 173.2 600.0 L 165.4 558.3 L 153.5 529.2 L 157.5 504.2 Z";

// Coordinate siti proiettate dalla stessa trasformazione lat/lon -> viewBox
const CITY_COORDS = {
  "Milano":[235,153],"Torino":[117,186],"Verona":[377,155],"Bolzano":[406,67],
  "Venezia":[482,155],"Genova":[215,241],"Bologna":[405,234],"Firenze":[398,294],
  "Ancona":[576,307],"Roma":[495,450],"L'Aquila":[567,412],"Napoli":[635,537],
  "Bari":[840,515],"Taranto":[869,569],"Cosenza":[791,667],"Reggio C.":[744,766],
  "Palermo":[564,765],"Catania":[700,817],"Cagliari":[230,673],"Sassari":[186,548],
};

function MapView({ sites, selectedId, onSelect, statusFilter, t }) {
  const wrapRef = React.useRef(null);
  const [hover, setHover] = React.useState(null);
  const [hoverPos, setHoverPos] = React.useState({ x: 0, y: 0 });

  const filtered = sites.filter(s => statusFilter === "all" ? true : s.status === statusFilter);

  return (
    <div className="map-wrap">
      <div className="map-tools">
        <div className="icon-btn" title="Zoom in"><I.zoomIn/></div>
        <div className="icon-btn" title="Zoom out"><I.zoomOut/></div>
        <div className="icon-btn" title="Centra"><I.target/></div>
      </div>
      <svg className="map-svg" viewBox="0 0 1000 1000" preserveAspectRatio="xMidYMid meet" ref={wrapRef}>
        <defs>
          <pattern id="mapDots" width="22" height="22" patternUnits="userSpaceOnUse">
            <circle cx="1" cy="1" r="0.7" fill="var(--line-2)" opacity="0.5"/>
          </pattern>
          <linearGradient id="italyFill" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%"   stopColor="var(--bg-3)"/>
            <stop offset="100%" stopColor="var(--bg-2)"/>
          </linearGradient>
          <radialGradient id="markerGlow" cx="50%" cy="50%">
            <stop offset="0%" stopColor="currentColor" stopOpacity="0.45"/>
            <stop offset="100%" stopColor="currentColor" stopOpacity="0"/>
          </radialGradient>
          <clipPath id="italyClip">
            <path d={ITALY_PATH}/>
            <path d={SICILY_PATH}/>
            <path d={SARDINIA_PATH}/>
          </clipPath>
        </defs>

        {/* Background dots grid */}
        <rect x="0" y="0" width="1000" height="1000" fill="url(#mapDots)"/>

        {/* Italy fill */}
        <g fill="url(#italyFill)" stroke="var(--line-2)" strokeWidth="1.4" strokeLinejoin="round">
          <path d={ITALY_PATH}/>
          <path d={SICILY_PATH}/>
          <path d={SARDINIA_PATH}/>
        </g>

        {/* Interior texture: contour lines */}
        <g clipPath="url(#italyClip)" stroke="var(--line-2)" strokeWidth="0.6" fill="none" opacity="0.5">
          {[...Array(16)].map((_, i) => (
            <path
              key={i}
              d={`M 0 ${80 + i*60} Q 500 ${60 + i*60 + (i%2?24:-24)}, 1000 ${80 + i*60}`}
            />
          ))}
        </g>

        {/* Fasce macro-aree */}
        <g clipPath="url(#italyClip)" opacity="0.07">
          <rect x="0" y="0"   width="1000" height="260" fill="var(--info)"/>
          <rect x="0" y="260" width="1000" height="180" fill="var(--ok)"/>
          <rect x="0" y="440" width="1000" height="260" fill="var(--warn)"/>
          <rect x="0" y="700" width="1000" height="300" fill="var(--crit)"/>
        </g>

        {/* Region labels */}
        <g fontFamily="var(--mono)" fontSize="11" letterSpacing="2" fill="var(--fg-muted)" opacity="0.55">
          <text x="300" y="80">NORD</text>
          <text x="470" y="340">CENTRO</text>
          <text x="720" y="560">SUD</text>
          <text x="180" y="495">SARDEGNA</text>
          <text x="560" y="900">SICILIA</text>
        </g>

        {/* Compass */}
        <g transform="translate(920, 80)" fill="var(--fg-muted)" opacity="0.75">
          <circle r="18" fill="none" stroke="var(--line-2)"/>
          <path d="M 0,-14 L 3,0 L 0,14 L -3,0 Z" fill="var(--fg-dim)"/>
          <text x="0" y="-22" textAnchor="middle" fontFamily="var(--mono)" fontSize="9" fill="var(--fg-dim)">N</text>
        </g>

        {/* Scale bar */}
        <g transform="translate(40, 960)" fontFamily="var(--mono)" fontSize="9" fill="var(--fg-muted)">
          <line x1="0" x2="120" y1="0" y2="0" stroke="var(--fg-muted)" strokeWidth="1"/>
          <line x1="0" x2="0" y1="-3" y2="3" stroke="var(--fg-muted)"/>
          <line x1="60" x2="60" y1="-3" y2="3" stroke="var(--fg-muted)"/>
          <line x1="120" x2="120" y1="-3" y2="3" stroke="var(--fg-muted)"/>
          <text x="0" y="-6">0</text>
          <text x="60" y="-6" textAnchor="middle">150</text>
          <text x="120" y="-6" textAnchor="middle">300 km</text>
        </g>

        {/* Markers */}
        {filtered.map(s => {
          const coords = CITY_COORDS[s.city] || ll2xy(s.lat, s.lon);
          const [x, y] = coords;
          const sel = s.id === selectedId;
          return (
            <g
              key={s.id}
              className={`site-marker ${s.status} ${sel ? "selected" : ""}`}
              transform={`translate(${x}, ${y})`}
              onClick={() => onSelect(s.id)}
              onMouseEnter={(e) => {
                setHover(s);
                const rect = wrapRef.current.getBoundingClientRect();
                const cx = rect.left + (x / 1000) * rect.width;
                const cy = rect.top + (y / 1000) * rect.height;
                setHoverPos({ x: cx, y: cy });
              }}
              onMouseLeave={() => setHover(null)}
            >
              {(s.status === "crit" || s.status === "warn") && (
                <circle className="marker-pulse" r={10}/>
              )}
              <circle className="marker-ring" r={sel ? 11 : 9}/>
              <circle className="marker-core" r={sel ? 5 : 4}/>
              {s.status === "crit" && (
                <circle r={sel ? 11 : 9} fill="url(#markerGlow)" style={{color: "var(--crit)"}}/>
              )}
              {sel && (
                <text y="-16" textAnchor="middle" fontFamily="var(--mono)" fontSize="10" fill="var(--fg)" fontWeight="600">{s.id}</text>
              )}
            </g>
          );
        })}
      </svg>

      {/* Hover card */}
      {hover && wrapRef.current && (
        <div className="site-card" style={{
          left: Math.min(hoverPos.x - wrapRef.current.getBoundingClientRect().left + 14, wrapRef.current.getBoundingClientRect().width - 232),
          top: Math.min(hoverPos.y - wrapRef.current.getBoundingClientRect().top + 14, wrapRef.current.getBoundingClientRect().height - 160),
        }}>
          <div className="name">{hover.name}</div>
          <div className="loc">{hover.city} · {hover.id}</div>
          <div className="row"><span>{t.capacity}</span><span>{hover.capacity.toFixed(1)} MWp</span></div>
          <div className="row"><span>{t.today}</span><span>{(hover.capacity * (4 + Math.sin(hover.lat)*1.5)).toFixed(1)} MWh</span></div>
          <div className="row"><span>Status</span>
            <span style={{color:
              hover.status === "ok" ? "var(--ok)" :
              hover.status === "warn" ? "var(--warn)" : "var(--crit)"
            }}>
              {hover.status === "ok" ? t.status_ok : hover.status === "warn" ? t.status_warn : t.status_crit}
            </span>
          </div>
        </div>
      )}

      <div className="map-legend">
        <div className="li"><span className="sw" style={{background: "var(--ok)"}}/>{t.status_ok}</div>
        <div className="li"><span className="sw" style={{background: "var(--warn)"}}/>{t.status_warn}</div>
        <div className="li"><span className="sw" style={{background: "var(--crit)"}}/>{t.status_crit}</div>
      </div>
    </div>
  );
}

window.MapView = MapView;
