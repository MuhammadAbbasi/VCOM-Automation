// Linea sottile, 16px, stile Linear/Datadog
const I = {
  grid: (p = {}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><rect x="2" y="2" width="5" height="5" rx="1"/><rect x="9" y="2" width="5" height="5" rx="1"/><rect x="2" y="9" width="5" height="5" rx="1"/><rect x="9" y="9" width="5" height="5" rx="1"/></svg>,
  map: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M5.5 2.5L2 4v9.5l3.5-1.5 5 1.5 3.5-1.5V2.5l-3.5 1.5-5-1.5z"/><path d="M5.5 2.5v10M10.5 4v10"/></svg>,
  chart: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M2 13h12M3.5 10V7M6.5 10V4M9.5 10V8M12.5 10V5"/></svg>,
  bell: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M8 2v1m0 0a4 4 0 014 4v3l1.5 2h-11L4 10V7a4 4 0 014-4zm-2 11a2 2 0 004 0"/></svg>,
  sliders: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M3 4h10M3 8h10M3 12h10"/><circle cx="10" cy="4" r="1.5" fill="currentColor"/><circle cx="5" cy="8" r="1.5" fill="currentColor"/><circle cx="11" cy="12" r="1.5" fill="currentColor"/></svg>,
  wrench: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M11 2a3 3 0 00-2.83 4L2.5 11.67 4.33 13.5 10 7.83A3 3 0 1011 2z"/></svg>,
  doc: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M3 2h6l4 4v8H3z"/><path d="M9 2v4h4M5 8h6M5 10.5h6M5 13h4"/></svg>,
  gear: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><circle cx="8" cy="8" r="2.2"/><path d="M8 2v1.5M8 12.5V14M2 8h1.5M12.5 8H14M3.8 3.8l1 1M11.2 11.2l1 1M12.2 3.8l-1 1M4.8 11.2l-1 1"/></svg>,
  sun: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><circle cx="8" cy="8" r="3"/><path d="M8 1v1.5M8 13.5V15M1 8h1.5M13.5 8H15M3.2 3.2l1 1M11.8 11.8l1 1M12.8 3.2l-1 1M4.2 11.8l-1 1"/></svg>,
  moon: (p={}) => <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}><path d="M13 9a5 5 0 01-6-6 5 5 0 106 6z"/></svg>,
  search: (p={}) => <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14"/></svg>,
  plus: (p={}) => <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><path d="M6 2v8M2 6h8"/></svg>,
  minus: (p={}) => <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><path d="M2 6h8"/></svg>,
  chev: (p={}) => <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}><path d="M4 3l3 3-3 3"/></svg>,
  up: (p={}) => <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 7l3-3 3 3"/></svg>,
  down: (p={}) => <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 5l3 3 3-3"/></svg>,
  zoomIn: (p={}) => <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14M5 7h4M7 5v4"/></svg>,
  zoomOut: (p={}) => <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="7" cy="7" r="4.5"/><path d="M10.5 10.5L14 14M5 7h4"/></svg>,
  target: (p={}) => <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><circle cx="8" cy="8" r="5.5"/><circle cx="8" cy="8" r="2"/><path d="M8 1v2M8 13v2M1 8h2M13 8h2"/></svg>,
  play: (p={}) => <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" {...p}><path d="M3 2l7 4-7 4z"/></svg>,
  stop: (p={}) => <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor" {...p}><rect x="3" y="3" width="6" height="6" rx="1"/></svg>,
  filter: (p={}) => <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" {...p}><path d="M2 4h12l-4 5v4l-4-1V9L2 4z"/></svg>,
};

window.I = I;
